
DASMx - A microprocessor opcode disassembler

(c) Copyright 1996-2003   Conquest Consultants

Version 1.40, 18th October 2003


This distribution contains the following files:

readme.txt               This file
DASMx.exe                Executable (a Win32 console application)
DASMx.htm                Documentation in HTML format
DASMx.pdf                Documentation in Adobe Acrobat format
checksum.exe             Checksum utility
examples\*.sym           Example symbol files

*** Please read the distribution, copyright and disclaimer notices
in the documentation. ***
